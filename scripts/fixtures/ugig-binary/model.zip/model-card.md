# Synthetic fixture
One weight; not a useful predictive model.
